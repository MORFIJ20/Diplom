package com.example.bt_def

object BluetoothConstants {
    const val PREFERENCES = "main_preferences"
    const val MAC = "mac"

}