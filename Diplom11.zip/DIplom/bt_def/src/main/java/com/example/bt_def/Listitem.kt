package com.example.bt_def

data class Listitem(
    val mane: String,
    val mac: String,
    val isChecked: Boolean
)
